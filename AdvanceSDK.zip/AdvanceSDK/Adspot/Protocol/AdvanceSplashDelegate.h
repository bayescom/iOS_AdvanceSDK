//
//  AdvanceSplashProtocol.h
//  AdvanceSDKExample
//
//  Created by 程立卿 on 2020/4/8.
//  Copyright © 2020 Mercury. All rights reserved.
//

#ifndef AdvanceSplashProtocol_h
#define AdvanceSplashProtocol_h

@protocol AdvanceSplashDelegate <NSObject>
@optional
/// 广告数据拉取成功
- (void)advanceSplashOnAdReceived;

/// 广告曝光成功
- (void)advanceSplashOnAdShow;

/// 广告渲染成功
- (void)advanceSplashOnAdRenderFailed;

/// 广告展示失败
- (void)advanceSplashOnAdFailedWithAdapterId:(NSString *)adapterId error:(NSError *)error;

/// 广告点击
- (void)advanceSplashOnAdClicked;

/// 广告点击跳过
- (void)advanceSplashOnAdSkipClicked;

/// 广告倒计时结束回调
- (void)advanceSplashOnAdCountdownToZero;

@end

#endif 
