//
//  UIWindow+Advance.h
//  BayesSDK
//
//  Created by CherryKing on 2020/1/9.
//  Copyright © 2020 BAYESCOM. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIApplication (Advance)
// 获取当前的Window
- (UIWindow *)by_getCurrentWindow;

@end

NS_ASSUME_NONNULL_END
